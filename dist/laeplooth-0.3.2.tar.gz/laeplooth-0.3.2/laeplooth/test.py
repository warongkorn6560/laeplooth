import sys
sys.path.append('/')
from main import loo


loo(sys.argv[1])
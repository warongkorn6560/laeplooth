
def loo(text):
    # result = Translator(text).getResult()
    print(text)
    return text








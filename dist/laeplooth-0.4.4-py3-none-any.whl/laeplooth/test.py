import sys

sys.path.append('/')
from main import loo

if __name__ == "__main__": 
    loo(sys.argv[1])



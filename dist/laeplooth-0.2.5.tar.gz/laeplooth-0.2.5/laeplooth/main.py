
from Thaispoon import Spoonerism


def loo(text):
    result = Spoonerism(text).Loolang()
    print(result)
    return result







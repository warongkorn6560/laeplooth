
from Thaispoon import Spoonerism


def loo(text):
    print(Spoonerism(text).Loolang())







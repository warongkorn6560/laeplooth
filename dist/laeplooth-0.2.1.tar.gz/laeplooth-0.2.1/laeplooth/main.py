
from Thaispoon import Spoonerism


def loo():
    print(Spoonerism('บันได').Loolang())

loo()






from .main import loo

def main(text):
    loo(text)

if __name__ == "__main__":
    main('อีดอก')

from .main import loo

def main():
    loo()

if __name__ == "__main__":
    main()
